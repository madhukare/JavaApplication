package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.OrderDetailsDao;
import com.dao.OrdersDao;
import com.dao.ProductDao;
import com.dao.UserDao;
import com.model.OrderDetails;
import com.model.Orders;
import com.model.Product;
import com.model.User;

@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		try {
			List<String> ctList = ProductDao.getAllCategories();
			List<Product> ptList = ProductDao.getAllProducts();
			session.setAttribute("catList", ctList);
			session.setAttribute("plist", ptList);
			request.getRequestDispatcher("home.jsp").forward(request, response);
		} catch (ServletException | IOException | ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		String button = request.getParameter("bt");

		PrintWriter out = response.getWriter();
		// System.out.println(button1);
		response.setContentType("text/html");
		if (button.equals("Register")) {
			String Name = request.getParameter("name");
			String Email = request.getParameter("email");
			String Pswd = request.getParameter("pwd");

			try {
				boolean EmailExisted = UserDao.ValidateUserWithEmail(Email);
				if (EmailExisted) {
					out.println("Email already exists");
				} else {
					if (UserDao.addUser(new User(Name, Email, Pswd))) {
						request.getRequestDispatcher("register.jsp").forward(request, response);
					} else {
						out.println("Not Registered");
					}
				}
			} catch (ClassNotFoundException | SQLException e) {

				e.printStackTrace();
			}
		} else if (button.equals("Login")) {
			String lemail = request.getParameter("lmail");
			String lpswd = request.getParameter("lpwd");

			try {
				if (UserDao.ValidateUserWithEmail(lemail)) {
					String dbpswd = UserDao.getPasswordWithEmail(lemail);
					if (lpswd.equals(dbpswd)) {
						String NAME = UserDao.getNameWithEmail(lemail);
						int uid = UserDao.getIdWithEmail(lemail);
						session.setAttribute("lname", NAME);
						session.setAttribute("userId", uid);
						request.getRequestDispatcher("login.jsp").forward(request, response);
					} else {
						out.println("Wrong Password");
						request.getRequestDispatcher("home.jsp").include(request, response);
					}
				} else {
					out.println("Enter correct email");
					request.getRequestDispatcher("home.jsp").include(request, response);
				}
			} catch (ClassNotFoundException | SQLException e) {

				e.printStackTrace();
			}
		} else if (button.equals("Go")) {
			String selectedCategory = request.getParameter("category");
			try {
				List<Product> prodList = ProductDao.getProductsWithCategory(selectedCategory);
				session.setAttribute("plist", prodList);
				request.getRequestDispatcher("home.jsp").forward(request, response);
			} catch (ClassNotFoundException | SQLException e) {
				e.printStackTrace();
			}

		} else if (button.equals("GO")) {
			String selectedCategory = request.getParameter("category");
			try {
				List<Product> prodList = ProductDao.getProductsWithCategory(selectedCategory);
				session.setAttribute("plist", prodList);
				request.getRequestDispatcher("login.jsp").forward(request, response);
			} catch (ClassNotFoundException | SQLException e) {
				e.printStackTrace();
			}

		} else if (button.equals("Add to Cart")) {
			int tp;
			List<Integer> qList = null;
			List<Integer> idList = null;
			List<Product> selectedItems = null;
			if (session.getAttribute("selectedItems") == null && session.getAttribute("qList") == null) {
				String id[] = request.getParameterValues("productId");
				String quantity[] = request.getParameterValues("Quantity");
				tp = 0;
				// Creating selected quantity list as well as selected item list
				qList = new ArrayList<Integer>();
				idList = new ArrayList<Integer>();
				selectedItems = new ArrayList<Product>();
				for (int i = 0; i < quantity.length && i < id.length; i++) {
					if (Integer.parseInt(quantity[i]) != 0) {
						qList.add(Integer.parseInt(quantity[i]));
						idList.add(Integer.parseInt(id[i]));
					}
				}

				for (int i = 0; i < idList.size(); i++) {
					try {
						Product pd = ProductDao.getProductDetailsWithId(idList.get(i));
						selectedItems.add(pd);
					} catch (ClassNotFoundException | SQLException e) {
						e.printStackTrace();
					}

				}
				// Billing
				for (int i = 0; i < qList.size() && i < selectedItems.size(); i++) {
					tp += qList.get(i) * selectedItems.get(i).getPrice();
				}

			} else {
				String id[] = request.getParameterValues("productId");
				String quantity[] = request.getParameterValues("Quantity");
				tp = (int) session.getAttribute("tp");
				qList = (List<Integer>) session.getAttribute("qList");
				int previousQSize = qList.size();
				idList = (List<Integer>) session.getAttribute("idList");
				selectedItems = (List<Product>) session.getAttribute("selectedItems");
				for (int i = 0; i < quantity.length && i < id.length; i++) {
					if (Integer.parseInt(quantity[i]) != 0) {
						qList.add(Integer.parseInt(quantity[i]));
						idList.add(Integer.parseInt(id[i]));
					}
				}
				for (int i = previousQSize; i < idList.size(); i++) {
					try {
						Product pd = ProductDao.getProductDetailsWithId(idList.get(i));
						selectedItems.add(pd);
					} catch (ClassNotFoundException | SQLException e) {
						e.printStackTrace();
					}

				}
				// Billing
				for (int i = previousQSize; i < qList.size() && i < selectedItems.size(); i++) {
					tp += qList.get(i) * selectedItems.get(i).getPrice();
				}

			}
			session.setAttribute("idList", idList);
			session.setAttribute("qList", qList);
			session.setAttribute("selectedItems", selectedItems);
			session.setAttribute("tp", tp);
			request.getRequestDispatcher("cart.jsp").forward(request, response);
		} else if (button.equals("Continue")) {
			int uId = (int) session.getAttribute("userId");
			int tAmount = (int) session.getAttribute("tp");
			Date d = new Date();
			Orders od = new Orders();
			User u = new User();
			u.setUid(uId);
			od.setUser_id(u);
			od.setTotalamount(tAmount);
			od.setOrderdate(new java.sql.Timestamp(d.getTime()));
			// Conversion of util date to sql date
			int insertSuccessCount = 0;
			try {
				if (OrdersDao.generateOrder(od)) {

					int orderId = OrdersDao.getIdWithUserId(od);
					od.setOid(orderId);
					List<Integer> quaList = (List<Integer>) session.getAttribute("qList");
					List<Product> purchasedProducts = (List<Product>) session.getAttribute("selectedItems");
					OrderDetails ord = null;
					for (int i = 0; i < quaList.size(); i++) {
						ord = new OrderDetails(od, purchasedProducts.get(i), quaList.get(i));
						if (OrderDetailsDao.insertPurchasedProduct(ord)) {
							insertSuccessCount++;
						}
					}

					if (insertSuccessCount == purchasedProducts.size()) {
						request.getRequestDispatcher("final.jsp").forward(request, response);
					} else {
						out.print("Product Details are not inserted");
					}
				} else {
					out.print("Not Generated");
				}
			} catch (ClassNotFoundException | SQLException e) {
				e.printStackTrace();
			}
		}

		else if (button.equals("YES")) {
			request.getRequestDispatcher("Logout.jsp").forward(request, response);
		} else if (button.equals("NO")) {
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}
	}

}
