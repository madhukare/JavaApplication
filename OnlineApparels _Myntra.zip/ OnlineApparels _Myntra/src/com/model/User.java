package com.model;

public class User {
	private int uid;
	private String uname;
	private String uemail;
	private String upwd;

	public User() {
		super();
	}

	public User(String uname, String uemail, String upwd) {
		super();

		this.uname = uname;
		this.uemail = uemail;
		this.upwd = upwd;
	}

	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getUemail() {
		return uemail;
	}

	public void setUemail(String uemail) {
		this.uemail = uemail;
	}

	public String getUpwd() {
		return upwd;
	}

	public void setUpwd(String upwd) {
		this.upwd = upwd;
	}

	@Override
	public String toString() {
		return "User [uid=" + uid + ", uname=" + uname + ", uemail=" + uemail + ", upwd=" + upwd + "]";
	}

}
