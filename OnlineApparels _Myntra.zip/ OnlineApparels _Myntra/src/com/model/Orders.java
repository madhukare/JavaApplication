package com.model;

import java.sql.Date;
import java.sql.Timestamp;

public class Orders {
	private int oid;
	private User user_id;
	private int totalamount;
	private Timestamp orderdate;

	public Orders() {
		super();
	}

	public Orders(int oid, User user_id, int totalamount, Timestamp orderdate) {
		super();
		this.oid = oid;
		this.user_id = user_id;
		this.totalamount = totalamount;
		this.orderdate = orderdate;
	}

	public int getOid() {
		return oid;
	}

	public void setOid(int oid) {
		this.oid = oid;
	}

	public User getUser_id() {
		return user_id;
	}

	public void setUser_id(User user_id) {
		this.user_id = user_id;
	}

	public int getTotalamount() {
		return totalamount;
	}

	public void setTotalamount(int totalamount) {
		this.totalamount = totalamount;
	}

	public Timestamp getOrderdate() {
		return orderdate;
	}

	public void setOrderdate(Timestamp orderdate) {
		this.orderdate = orderdate;
	}

	@Override
	public String toString() {
		return "Orders [oid=" + oid + ", user_id=" + user_id + ", totalamount=" + totalamount + ", orderdate="
				+ orderdate + "]";
	}

}