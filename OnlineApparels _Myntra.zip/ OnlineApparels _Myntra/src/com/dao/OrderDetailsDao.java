package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.model.OrderDetails;

public class OrderDetailsDao {

	public static boolean insertPurchasedProduct(OrderDetails od) throws ClassNotFoundException, SQLException {
		Connection c = ConnectionUtility.getConnection();
		PreparedStatement ps = c
				.prepareStatement("insert into order_details(order_id,product_id,quantity)values(?,?,?)");
		ps.setInt(1, od.getOrder_id().getOid());
		ps.setInt(2, od.getProduct_id().getPid());
		ps.setInt(3, od.getQuantity());
		if (ps.executeUpdate() != 0) {
			return true;
		}
		return false;
	}

}
