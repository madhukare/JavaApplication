package model;

public class details {

	private int id;
	private String name;
	private String country;
	private int score;

	public details() {
		super();
	}

	public details(String name, String country, int score) {
		super();
		this.name = name;
		this.country = country;
		this.score = score;
	}

	public details(int id, String name, String country, int score) {
		super();
		this.id = id;
		this.name = name;
		this.country = country;
		this.score = score;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	@Override
	public String toString() {
		return "details [id=" + id + ", name=" + name + ", country=" + country + ", score=" + score + "]";
	}

}
