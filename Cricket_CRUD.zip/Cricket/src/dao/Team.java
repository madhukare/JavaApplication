package dao;

public class Team {

}
