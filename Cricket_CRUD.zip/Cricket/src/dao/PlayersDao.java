package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.ConnectionUtility;

import model.details;

public class PlayersDao {

	public static List<details> getAllPlayersDetails() throws ClassNotFoundException, SQLException {

		Connection c = ConnectionUtility.getConnection();
		PreparedStatement ps = c.prepareStatement("select * from player");
		ResultSet rs = ps.executeQuery();

		details p = null;
		List<details> pList = new ArrayList<details>();
		while (rs.next()) {

			p = new details(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4));
			pList.add(p);
		}
		return pList;
	}

	public static boolean addPlayers(details t) throws ClassNotFoundException, SQLException {
		Connection c = ConnectionUtility.getConnection();
		PreparedStatement ps = c.prepareStatement("insert into player(name,country,score)values(?,?,?)");
		ps.setString(1, t.getName());
		ps.setString(2, t.getCountry());
		ps.setInt(3, t.getScore());
		int val = ps.executeUpdate();
		if (val != 0) {
			return true;
		}

		return false;

	}

	public static boolean ValidatePlayerWithName(String name) throws ClassNotFoundException, SQLException {
		Connection c = ConnectionUtility.getConnection();
		PreparedStatement ps = c.prepareStatement("select name from player");
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			if (name.equals(rs.getString(1))) {
				return true;
			}
		}
		return false;
	}

	public static boolean updatePlayerWithId(details t) throws ClassNotFoundException, SQLException {
		Connection c = ConnectionUtility.getConnection();
		PreparedStatement ps = c.prepareStatement("update player set score=?,name=? where player_id=?");
		ps.setInt(1, t.getScore());
		ps.setString(2, t.getName());
		ps.setInt(3, t.getId());
		int r = ps.executeUpdate();
		if (r != 0) {
			return true;
		}

		return false;

	}

	public static boolean deletePlayerWithId(int id) throws ClassNotFoundException, SQLException {
		Connection c = ConnectionUtility.getConnection();
		PreparedStatement ps = c.prepareStatement("delete from player where player_id=?");
		ps.setInt(1, id);
		int r = ps.executeUpdate();
		if (r != 0) {
			return true;
		}

		return false;
	}

	public static List<details> getPlayerWithId(int id) throws ClassNotFoundException, SQLException {
		Connection c = ConnectionUtility.getConnection();
		PreparedStatement ps = c.prepareStatement("select * from player where player_id=?");
		ps.setInt(1, id);

		ResultSet rs = ps.executeQuery();

		details p = null;
		List<details> pList = new ArrayList<details>();
		while (rs.next()) {

			p = new details(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4));
			pList.add(p);
		}
		return pList;

	}

}
