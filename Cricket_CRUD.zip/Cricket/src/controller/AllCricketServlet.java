package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.PlayersDao;
import model.details;

/**
 * Servlet implementation class AllCricketServlet
 */
@WebServlet("/AllCricketServlet")
public class AllCricketServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String button = request.getParameter("bt");
		HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();

		if (button.equals("AllCricketers")) {
			response.setContentType("text/html");
			List<details> playersList;
			try {
				playersList = PlayersDao.getAllPlayersDetails();
				request.setAttribute("plist", playersList);
				request.getRequestDispatcher("PlayersList.jsp").forward(request, response);

			} catch (ClassNotFoundException | SQLException e) {
				e.printStackTrace();
			}
		} else if (button.equals("Add")) {

			String Name = request.getParameter("name");
			String Country = request.getParameter("country");
			String score = request.getParameter("score");
			int Score = Integer.parseInt(score);
			try {
				boolean PlayerExisted = PlayersDao.ValidatePlayerWithName(Name);
				if (PlayerExisted) {
					out.println("Name already exists");
				} else {
					if (PlayersDao.addPlayers(new details(Name, Country, Score))) {
						List<details> playersList;

						playersList = PlayersDao.getAllPlayersDetails();
						request.setAttribute("plist", playersList);
						request.getRequestDispatcher("PlayersList.jsp").forward(request, response);
						out.println("Added");

					} else {
						out.println("Not Added");
					}

				}
			} catch (ClassNotFoundException | SQLException e) {

				e.printStackTrace();
			}
		}

		else if (button.equals("Update")) {
			String Name = request.getParameter("playerName");
			String Country = request.getParameter("playerCountry");
			int score = Integer.parseInt(request.getParameter("playerScore"));
			int playerid = Integer.parseInt(request.getParameter("playerId"));
			response.setContentType("text/html");
			try {
				List<details> playersList;
				boolean update = PlayersDao.updatePlayerWithId(new details(playerid, Name, Country, score));
				if (update) {
					playersList = PlayersDao.getAllPlayersDetails();
					session.setAttribute("plist", playersList);
					request.getRequestDispatcher("PlayersList.jsp").forward(request, response);
				} else {
					out.println("Not updated");
				}

			} catch (ClassNotFoundException | SQLException e) {

				e.printStackTrace();
			}
		} else if (button.equals("Delete")) {

			try {
				int id = Integer.parseInt(request.getParameter("playerId"));
				boolean delete = PlayersDao.deletePlayerWithId(id);
				if (delete) {
					List<details> playersList;
					playersList = PlayersDao.getAllPlayersDetails();
					session.setAttribute("plist", playersList);
					RequestDispatcher rd = request.getRequestDispatcher("PlayersList.jsp");
					rd.forward(request, response);
				} else {
					out.println("Not deleted");
				}

			} catch (ClassNotFoundException | SQLException e) {
				e.printStackTrace();
			}
		}

		else if (button.equals("select")) {

			try {
				int id = Integer.parseInt(request.getParameter("playerId"));
				List<details> playersList = PlayersDao.getPlayerWithId(id);

				/* playersList = PlayersDao.getAllPlayersDetails(); */
				session.setAttribute("plist", playersList);

				RequestDispatcher rd = request.getRequestDispatcher("edit.jsp");
				rd.forward(request, response);

			} catch (ClassNotFoundException | SQLException e) {
				e.printStackTrace();

			}

		}
	}
}
