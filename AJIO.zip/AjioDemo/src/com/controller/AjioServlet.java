package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.OrderDetailsDao;
import com.dao.OrdersDao;
import com.dao.ProductDao;
import com.dao.UserDao;
import com.model.OrderDetails;
import com.model.Orders;
import com.model.Product;
import com.model.User;

@WebServlet("/AjioServlet")
public class AjioServlet extends HttpServlet {
private static final long serialVersionUID = 1L;

protected void doGet(HttpServletRequest request, HttpServletResponse response)
throws ServletException, IOException {
HttpSession session = request.getSession();
List<String> ctList;
try {
ctList = ProductDao.getAllCategories();
List<Product> plist = ProductDao.getAllProducts();
session.setAttribute("ctList", ctList);
session.setAttribute("plist", plist);
request.getRequestDispatcher("loginhome.jsp").forward(request, response);

} catch (ClassNotFoundException | SQLException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}

}

protected void doPost(HttpServletRequest request, HttpServletResponse response)
throws ServletException, IOException {
UserDao ud = new UserDao();
HttpSession session = request.getSession();

String button = request.getParameter("action");
PrintWriter out = response.getWriter();
response.setContentType("text/html");
if (button.equals("Login")) {
String email = request.getParameter("mail");
String upwd = request.getParameter("pwd");
try {
if (UserDao.checkAvailability(email)) {
String dbpwd = UserDao.getPasswordWithEmail(email);
if (upwd.equals(dbpwd)) {
String name = UserDao.getNameByEmail(email);
session.setAttribute("name", name);
int userId = UserDao.getIdByEmail(email);
session.setAttribute("userId", userId);
RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
rd.forward(request, response);
} else {
out.println("Sorry invalid password");
RequestDispatcher rd = request.getRequestDispatcher("loginhome.jsp");
rd.include(request, response);
}
} else {
out.println("enter correct email");
RequestDispatcher rd = request.getRequestDispatcher("loginhome.jsp");
rd.include(request, response);

}

} catch (ClassNotFoundException | SQLException e) {
e.printStackTrace();
}
} else if (button.equals("Register")) {
String uname = request.getParameter("name");
String email = request.getParameter("mail");
String upwd = request.getParameter("pwd");
try {
if (UserDao.checkAvailability(email)) {
out.println("Already registered");
} else if (UserDao.registerUser(new User(uname, email, upwd))) {
RequestDispatcher rd = request.getRequestDispatcher("register.jsp");
rd.forward(request, response);

}
} catch (ClassNotFoundException | SQLException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
} else if (button.equals("Go")) {
String selectedCategory = request.getParameter("category");
try {
List<Product> iList = ProductDao.getItemsWithCategory(selectedCategory);
request.setAttribute("plist", iList);
request.getRequestDispatcher("loginhome.jsp").forward(request, response);

} catch (ClassNotFoundException | SQLException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}

} else if (button.equals("GO")) {
String selectedCategory = request.getParameter("category");
try {
List<Product> iList = ProductDao.getItemsWithCategory(selectedCategory);
request.setAttribute("plist", iList);
request.getRequestDispatcher("login.jsp").forward(request, response);

} catch (ClassNotFoundException | SQLException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}

} else if (button.equals("AddToCart")) {
int tp;
List<Integer> qList = null;
List<Integer> idList = null;
List<Product> selectedItems = null;
if (session.getAttribute("selectedItems") == null && session.getAttribute("qList") == null) {
String id[] = request.getParameterValues("itemId");
String quantity[] = request.getParameterValues("quantity");
tp = 0;
qList = new ArrayList<Integer>();
idList = new ArrayList<Integer>();
selectedItems = new ArrayList<Product>();

for (int i = 0; i < quantity.length && i < id.length; i++) {
if (Integer.parseInt(quantity[i]) != 0) {
qList.add(Integer.parseInt(quantity[i]));
idList.add(Integer.parseInt(id[i]));
}
}

for (int i = 0; i < idList.size(); i++) {
Product it;
try {
it = ProductDao.getItemsWithId(idList.get(i));
selectedItems.add(it);
} catch (ClassNotFoundException | SQLException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}

}
for (int i = 0; i < qList.size() && i < selectedItems.size(); i++) {
tp += qList.get(i) * selectedItems.get(i).getPrice();
}
} else {
String id[] = request.getParameterValues("itemId");
String quantity[] = request.getParameterValues("quantity");

tp = (int) session.getAttribute("tp");
qList = (List<Integer>) session.getAttribute("qList");
int previousQSize = qList.size();
idList = (List<Integer>) session.getAttribute("idList");
selectedItems = (List<Product>) session.getAttribute("selectedItems");

for (int i = 0; i < quantity.length && i < id.length; i++) {
if (Integer.parseInt(quantity[i]) != 0) {
qList.add(Integer.parseInt(quantity[i]));
idList.add(Integer.parseInt(id[i]));
}
}

for (int i = previousQSize; i < idList.size(); i++) {
Product it;
try {
it = ProductDao.getItemsWithId(idList.get(i));
selectedItems.add(it);
} catch (ClassNotFoundException | SQLException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}

}
for (int i = previousQSize; i < qList.size() && i < selectedItems.size(); i++) {
tp += qList.get(i) * selectedItems.get(i).getPrice();
}

}
session.setAttribute("idList", idList);
session.setAttribute("qList", qList);
session.setAttribute("selectedItems", selectedItems);
session.setAttribute("tp", tp);
request.getRequestDispatcher("cart.jsp").forward(request, response);

} else if (button.equals("Continue")) {
int uId = (int) session.getAttribute("userId");
int tAmount = (int) session.getAttribute("tp");
Date d = new Date();
Orders od = new Orders();
User u = new User();
u.setId(uId);
od.setUserId(u);
od.setTotalAmount(tAmount);
od.setDate(new java.sql.Timestamp(d.getTime()));
int insertSuccessCount = 0;
try {
if (OrdersDao.generateOrder(od)) {
out.println("Generated");
int orderId = OrdersDao.getOrderIdByUserId(od);
od.setId(orderId);
List<Integer> quaList = (List<Integer>) session.getAttribute("qList");
List<Product> purchasedProducts = (List<Product>) session.getAttribute("selectedItems");
OrderDetails ord = null;

for (int i = 0; i < quaList.size(); i++) {
ord = new OrderDetails(od, purchasedProducts.get(i), quaList.get(i));
if (OrderDetailsDao.insertOrderDetails(ord)) {
insertSuccessCount++;
}
}
if (insertSuccessCount == purchasedProducts.size()) {
request.getRequestDispatcher("final.jsp").forward(request, response);
} else {
out.println("Order details not entered into order_details");
}

} else {
out.println("Not Generated");
}
} catch (ClassNotFoundException | SQLException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
}

}

}


