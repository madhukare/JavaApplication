package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.model.OrderDetails;


public class OrderDetailsDao {
	public static boolean insertOrderDetails(OrderDetails od) throws ClassNotFoundException, SQLException {
		Connection c = ConnectionUtility.getConnection();
		PreparedStatement ps = c.prepareStatement("insert into order_details(order_id,product_id,quantity) values(?,?,?)");
		ps.setInt(1,od.getOrderId().getId());
		ps.setInt(2, od.getProductId().getId());
		ps.setInt(3,od.getQuantity());
		int val = ps.executeUpdate();
		if (val != 0) {
			return true;
		}
		return false;

	}

}
