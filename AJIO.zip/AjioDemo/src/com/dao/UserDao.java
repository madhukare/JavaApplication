package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.model.Product;
import com.model.User;

public class UserDao {
	public static String getPasswordWithEmail(String email) throws ClassNotFoundException, SQLException{
		Connection c = ConnectionUtility.getConnection();
		PreparedStatement ps = c.prepareStatement("select aes_decrypt(password,'k1') from user where email = ?");
		ps.setString(1, email);
		ResultSet rs = ps.executeQuery();
		String pswd=null;
		while(rs.next()){
			pswd=rs.getString(1);
		}
		return pswd;
	}
	public static String getNameByEmail(String email) throws ClassNotFoundException, SQLException{
		Connection c = ConnectionUtility.getConnection();
		PreparedStatement ps = c.prepareStatement("select name from user where  email= ?");
		ps.setString(1, email);
		ResultSet rs = ps.executeQuery();
		String name=null;
		while(rs.next()){
			name=rs.getString(1);
		}
		return name;
		
	}
	public static int getIdByEmail(String email) throws ClassNotFoundException, SQLException{
		Connection c = ConnectionUtility.getConnection();
		PreparedStatement ps = c.prepareStatement("select uid from user where  email= ?");
		ps.setString(1, email);
		ResultSet rs = ps.executeQuery();
		int uId;
		while(rs.next()){
			uId = rs.getInt(1);
			return uId;
		}
		return 0;
		
	}
	
	public static boolean checkAvailability(String email) throws ClassNotFoundException, SQLException{
		Connection c = ConnectionUtility.getConnection();
		PreparedStatement ps1 = c.prepareStatement("select * from user where email=?");
		ps1.setString(1,email);
		ResultSet rs = ps1.executeQuery();
		
		while (rs.next()) {
			
			return true;
			
			
		}
		return false;
	}
	public static boolean registerUser(User u){
		
		try {
			Connection c = ConnectionUtility.getConnection();
			PreparedStatement ps = c.prepareStatement("insert into user(name,email,password) values(?,?,aes_encrypt(?,'k1'))");
			ps.setString(1, u.getName());
			ps.setString(2, u.getEmail());
			ps.setString(3, u.getPwd());
			int count = ps.executeUpdate();
			c.close();
			if(count != 0)
				return true;

		} catch (Exception e) {
			
		}
		return false;
		
	}


}
