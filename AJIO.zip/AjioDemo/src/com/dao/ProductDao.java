package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.model.Product;

public class ProductDao {
	public static List<String> getAllCategories() throws ClassNotFoundException, SQLException {
		Connection c = ConnectionUtility.getConnection();
		PreparedStatement ps = c.prepareStatement("select distinct category from product");
		ResultSet rs = ps.executeQuery();
		List<String> cList = new ArrayList<String>();
		String category;
		while (rs.next()) {
			category = rs.getString(1);
			cList.add(category);

		}
		return cList;
	}

	public static List<Product> getAllProducts() throws ClassNotFoundException, SQLException {
		Connection c = ConnectionUtility.getConnection();
		PreparedStatement ps = c.prepareStatement("Select * from product");
		ResultSet rs = ps.executeQuery();
		Product p = null;
		List<Product> Ilist = new ArrayList<Product>();
		int pId, price;
		String name, imageUrl, category;
		while (rs.next()) {
			pId = rs.getInt(1);
			name = rs.getString(2);
			price = rs.getInt(3);
			imageUrl = rs.getString(4);
			category = rs.getString(5);
			p = new Product(pId, name, price, imageUrl, category);
			Ilist.add(p);
		}

		return Ilist;
	}

	public static List<Product> getItemsWithCategory(String ct) throws ClassNotFoundException, SQLException {
		Connection c = ConnectionUtility.getConnection();
		PreparedStatement ps = c.prepareStatement("Select * from product where category=?");
		ps.setString(1, ct);
		ResultSet rs = ps.executeQuery();
		Product p = null;
		List<Product> Ilist = new ArrayList<Product>();
		int pId, price;
		String name, imageUrl, category;
		while (rs.next()) {
			pId = rs.getInt(1);
			name = rs.getString(2);
			price = rs.getInt(3);
			imageUrl = rs.getString(4);
			category = rs.getString(5);
			p = new Product(pId, name, price, imageUrl, category);
			Ilist.add(p);
		}

		return Ilist;
	}

	public static Product getItemsWithId(int id) throws ClassNotFoundException, SQLException {
		Connection c = ConnectionUtility.getConnection();
		PreparedStatement ps = c.prepareStatement("Select * from product where pid=?");
		ps.setInt(1, id);
		ResultSet rs = ps.executeQuery();
		Product p = null;
		int pId, price;
		String name, imageUrl, category;
		while (rs.next()) {
			pId = rs.getInt(1);
			name = rs.getString(2);
			price = rs.getInt(3);
			imageUrl = rs.getString(4);
			category = rs.getString(5);
			p = new Product(pId,name ,price ,imageUrl ,category);

		}

		return p;
	}

}
